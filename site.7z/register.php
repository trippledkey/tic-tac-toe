<?php
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$password_confirm = $_POST['password_confirm'];
echo "username: " . $username . "<br>";
echo "password: " . $password . "<br>";
echo "email" . $email . "<br>";
echo "password_confirm" . $password_confirm . "<br>";

if ($password != $password_confirm) { 
    echo "Пароли не совпадают"; die();
 }

$conn = new mysqli("127.0.0.1","sa","sa","registration_test");

if ($conn->connect_error) {die ("Ошибка соединения: ") .$conn->connect_error; } 


$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);
if (!$result) {
    echo "Ошибка запроса";
    die();
}
if ($result->num_rows > 0) {
    echo "Пользователь с таким Email уже существует";
    die();
}
$sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
$result = $conn->query($sql);
if (!$result) {
    echo "Ошибка создания пользователя";
    die();
}
header("Location: field.html");
exit;


