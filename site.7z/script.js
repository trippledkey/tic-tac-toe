document.addEventListener("DOMContentLoaded", function() {
    const startBtn = document.getElementById("start-btn");
    const gameBoard = document.getElementById("game-board");
    const timer = document.getElementById("timer");
    const playerTurn = document.getElementById("player-turn");

    let currentPlayer = "X";
    let timerInterval;
    let timeElapsed = 0;

    startBtn.addEventListener("click", startGame);

    function startGame() {
        resetBoard();
        resetTimer();

        timerInterval = setInterval(updateTimer, 1000);
        updatePlayerTurn();
        createGameCells();

        gameBoard.querySelectorAll(".cell").forEach(cell => {
            cell.addEventListener("click", handleCellClick, { once: true });
        });
    }

    function resetBoard() {
        gameBoard.innerHTML = "";
    }

    function resetTimer() {
        clearInterval(timerInterval);
        timeElapsed = 0;
        timer.textContent = timeElapsed;
    }

    function updateTimer() {
        timeElapsed++;
        timer.textContent = timeElapsed;
    }

    function updatePlayerTurn() {
        playerTurn.textContent = `Ходит игрок: ${currentPlayer}`;
    }

    function createGameCells() {
        for (let i = 0; i < 9; i++) {
            const cell = document.createElement("div");
            cell.classList.add("cell");
            gameBoard.appendChild(cell);
        }
    }

    function handleCellClick(event) {
        const cell = event.target;
        cell.textContent = currentPlayer;

        if (checkWin()) {
            clearInterval(timerInterval);
            alert(`Победил игрок ${currentPlayer}!`);
            resetGame();
            return;
        }

        if (checkDraw()) {
            clearInterval(timerInterval);
            alert("Ничья!");
            resetGame();
            return;
        }

        currentPlayer = currentPlayer === "X" ? "O" : "X";
        updatePlayerTurn();
    }

    function checkWin() {
        const winConditions = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6]
        ];

        for (let condition of winConditions) {
            if (gameBoard.children[condition[0]].textContent === currentPlayer &&
                gameBoard.children[condition[1]].textContent === currentPlayer &&
                gameBoard.children[condition[2]].textContent === currentPlayer) {
                return true;
            }
        }

        return false;
    }

    function checkDraw() {
        for (let cell of gameBoard.children) {
            if (cell.textContent === "") {
                return false;
            }
        }
        return true;
    }

    function resetGame() {
        gameBoard.querySelectorAll(".cell").forEach(cell => {
            cell.removeEventListener("click", handleCellClick);
        });
        startBtn.textContent = "Сыграть еще раз";
        startBtn.addEventListener("click", startGame);
    }

});


function sendMessage() {
    const messagesenderInput = document.getElementById("message-sender");
    const messagesender = messagesenderInput.value;
    const messageInput = document.getElementById("message-input");
    const message = messageInput.value;
    const messageList = document.getElementById("message-container");
    const messageItem = document.createElement("div");
    messageItem.innerHTML = `<b>${messagesender}</b>: ${message}`;
    messageList.appendChild(messageItem);
    messageInput.value = "";
}

