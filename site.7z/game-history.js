// Создаем массив для хранения истории игр
let gameHistory = [];

// Функция для добавления игры в историю
function addToHistory(player1, player2, winner, moves) {
    gameHistory.push({ player1, player2, winner, moves });
}

// Пример добавления игры в историю
let player1 = 'Игрок 1';
let player2 = 'Игрок 2';
let winner = 'Игрок 1';
let moves = [
    ['X', '', 'O'],
    ['', 'X', 'O'],
    ['X', 'O', 'X']
    
];

addToHistory(player1, player2, winner, moves);

// Вывод истории игр на страницу HTML
const gameHistoryList = document.getElementById('game-history-list');
gameHistory.forEach(game => {
    const gameElement = document.createElement('div');
    gameElement.innerHTML = `
        <p><strong>Игрок 1:</strong> ${game.player1}</p>
        <p><strong>Игрок 2:</strong> ${game.player2}</p>
        <p><strong>Победитель:</strong> ${game.winner}</p>
        <p><strong>Ходы:</strong></p>
        <ul>
            ${game.moves.map(row => `<li>${row.join('')}</li>`).join('')}
        </ul>
        <hr>
    `;
    gameHistoryList.appendChild(gameElement);
});